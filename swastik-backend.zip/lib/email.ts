import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendEmail(appointment: any) {
  const { fullName, email, phone, appointmentDate, testType, message } = appointment;

  await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL!,
    to: process.env.CLINIC_EMAIL!,
    subject: 'New Appointment Booking',
    html: `
      <h2>New Appointment Request</h2>
      <p><strong>Name:</strong> ${fullName}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Phone:</strong> ${phone}</p>
      <p><strong>Date:</strong> ${appointmentDate}</p>
      <p><strong>Test Type:</strong> ${testType}</p>
      <p><strong>Message:</strong> ${message}</p>
    `,
  });
}