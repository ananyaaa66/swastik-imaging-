# Swastik Imaging Backend Setup

## How to Use

1. Duplicate `.env.local.example` as `.env.local` and fill in your keys.
2. Make sure the Supabase table `appointments` exists with:
   - fullName (text)
   - email (text)
   - phone (text)
   - appointmentDate (date)
   - testType (text)
   - message (text)

## API Endpoints

- **POST** `/api/book-appointment`  
  → Saves appointment + sends email

- **GET** `/api/admin/appointments`  
  → Requires `Authorization: Bearer <ADMIN_API_TOKEN>`

## Deploy

Push this to Vercel with your `.env.local` setup.